//
// Created by Srihari Vishnu on 2020-10-04.
//
#include "Context.h"
#ifndef NOVA_STDFUNCS_H
#define NOVA_STDFUNCS_H
    void addStdFunctions(const Context& context);
#endif //NOVA_STDFUNCS_H
